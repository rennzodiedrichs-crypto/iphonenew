---
name: Brand color tokens
description: Complete color system — void/surface/gold/white with HSL CSS variables
type: design
---
Void #070707, BG #0C0C0C, Surface #111, Surface-2 #171717, Surface-3 #1E1E1E
Gold #F5A800, Gold-bright #FFD060, Gold-muted #B07800
Gold-glow rgba(245,168,0,0.15), Gold-glow-2 0.30
White-70 0.70, White-40 0.40, White-10 0.10, White-05 0.05
Border rgba(245,168,0,0.14), Border-hover 0.45
All defined as HSL in index.css :root
