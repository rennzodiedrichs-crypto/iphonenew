# Project Memory

## Core
Luxury dark tech boutique. Gold #F5A800 on void #070707. Cormorant Garamond hero headlines, Outfit body, DM Mono tags. No purple. No white backgrounds. No Inter/Roboto.
All WhatsApp links → https://wa.me/5563930002112
Brand: iPHO(white semibold Outfit) NEW(gold bold italic Outfit) STORE(white-70 light Outfit tracking-wide)

## Memories
- [Brand colors](mem://design/brand-colors) — Full CSS variable system with gold, void, surface, border tokens
- [Typography](mem://design/typography) — Cormorant Garamond 700 headlines, Outfit 300-600 body, DM Mono 400 tags
